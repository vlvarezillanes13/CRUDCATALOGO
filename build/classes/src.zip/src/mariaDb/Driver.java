/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mariaDb;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;



public class Driver 
{
    String url = "jdbc:mysql://localhost:3306/Prueba3";
    String user = "root";
    String password = "1234";
    public Connection conne = null;
    private Statement stm;
    private ResultSet resu;
    
public void connect() {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            conne = DriverManager.getConnection(url,user,password);
            
        }
           
        }
            Connection conn = DriverManager.getConnection(url, user, password);
            this.conne = conne;

            Statement myStmt = conn.createStatement();
            this.stm = myStmt;
            
            resu = stm.executeQuery("select * from Proyecto");

            while (resu.next()){
    }
    
    
}
